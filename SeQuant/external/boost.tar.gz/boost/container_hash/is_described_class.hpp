// Copyright 2022 Peter Dimov.
// Distributed under the Boost Software License, Version 1.0.
// https://www.boost.org/LICENSE_1_0.txt

#ifndef SEQUANT_BOOST_HASH_IS_DESCRIBED_CLASS_HPP_INCLUDED
#define SEQUANT_BOOST_HASH_IS_DESCRIBED_CLASS_HPP_INCLUDED

#include <SeQuant/external/boost/type_traits/integral_constant.hpp>
#include <SeQuant/external/boost/type_traits/is_union.hpp>
#include <SeQuant/external/boost/describe/bases.hpp>
#include <SeQuant/external/boost/describe/members.hpp>

namespace sequant_boost
{
namespace container_hash
{

#if defined(BOOST_DESCRIBE_CXX11)

template<class T> struct is_described_class: sequant_boost::integral_constant<bool,
    describe::has_describe_bases<T>::value &&
    describe::has_describe_members<T>::value &&
    !sequant_boost::is_union<T>::value>
{
};

#else

template<class T> struct is_described_class: sequant_boost::false_type
{
};

#endif

} // namespace container_hash
} // namespace sequant_boost

#endif // #ifndef SEQUANT_BOOST_HASH_IS_DESCRIBED_CLASS_HPP_INCLUDED
